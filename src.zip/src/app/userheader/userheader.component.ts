import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ValidateService } from '../validate.service';

@Component({
  selector: 'app-userheader',
  templateUrl: './userheader.component.html',
  styleUrls: ['./userheader.component.css']
})
export class UserheaderComponent implements OnInit {
  constructor(private router: Router, private service: ValidateService) { }

  ngOnInit() {
  }

  logOut() {
    this.service.setUserLoggedOut();
    this.router.navigate(['login']);
  }

}
