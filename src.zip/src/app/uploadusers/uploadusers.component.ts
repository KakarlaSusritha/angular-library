import { Component, OnInit, ViewChild } from '@angular/core';
import { UserCSVRecord } from './UserCSVModel';
import { UserService } from '../user.service';

@Component({
  selector: 'app-uploadusers',
  templateUrl: './uploadusers.component.html',
  styleUrls: ['./uploadusers.component.css']
})
export class UploadusersComponent implements OnInit {
  
  constructor(private userService : UserService) { }

  booksRecords = [];
  usersRecords = [];
  @ViewChild('csvReaderBook') csvReaderBook: any;
  @ViewChild('csvReaderUser') csvReaderUser: any;


  uploadListener2($event: any): void {
    let text = [];
    let files = $event.srcElement.files;
    if (this.isValidCSVFile(files[0])) {
      let input = $event.target;
      let reader = new FileReader();
      reader.readAsText(input.files[0]);
      reader.onload = () => {
        let csvData = reader.result;
        let csvRecordsArray = (<string>csvData).split(/\r\n|\n/);

        let headersRow = this.getHeaderArray(csvRecordsArray);

        this.usersRecords = this.getUsersData(csvRecordsArray, headersRow.length);
        var jsonArray = JSON.parse(JSON.stringify(this.usersRecords));
        console.log(jsonArray);
        this.userService.registerUsers(jsonArray).subscribe();
      };
      reader.onerror = function () {
        console.log('error is occured while reading file!');
      };

    } else {
      alert("Please import valid .csv file.");
      this.usersReset();
    }
  }

  getUsersData(csvRecordsArray: any, headerLength: any) {
    let csvArr = [];

    for (let i = 1; i < csvRecordsArray.length; i++) {
      let curruntRecord = (<string>csvRecordsArray[i]).split(',');
      if (curruntRecord.length == headerLength) {
        let csvRecord: UserCSVRecord  = new UserCSVRecord();
        csvRecord.userId = curruntRecord[0].trim();
        csvRecord.userName = curruntRecord[1].trim();
        csvRecord.loginId= curruntRecord[2].trim();
        csvRecord.userPassword= curruntRecord[3].trim();
        csvRecord.department= curruntRecord[4].trim();
        csvArr.push(csvRecord);
      }
    }
    return csvArr;
  }

  usersReset() {
    this.csvReaderUser.nativeElement.value = "";
    this.usersRecords = [];
  }

  isValidCSVFile(file: any) {
    return file.name.endsWith(".csv");
  }

  getHeaderArray(csvRecordsArr: any) {
    let headers = (<string>csvRecordsArr[0]).split(',');
    let headerArray = [];
    for (let j = 0; j < headers.length; j++) {
      headerArray.push(headers[j]);
    }
    return headerArray;
  }

  ngOnInit() {
    
  }
}
