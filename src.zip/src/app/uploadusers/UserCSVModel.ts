export class UserCSVRecord {
    userId: any;
    userName: any;
    loginId: any;
    userPassword: any;
    department: any;
}