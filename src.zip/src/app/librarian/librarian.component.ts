import { Component, OnInit } from '@angular/core';
import { UserService } from '../user.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-librarian',
  templateUrl: './librarian.component.html',
  styleUrls: ['./librarian.component.css']
})
export class LibrarianComponent implements OnInit {
  books : any;
  constructor(private router: Router, private service : UserService) {
    this.books = [];
    
  }
  
  ngOnInit() {
    this.service.getAllBooks().subscribe(data =>{
      this.books = data;
      //console.log(this.books);
     /* for (let i of this.books) {
        
        this.service.addToTable(i.count);
        i.count = this.service.getCount();
        console.log(i.count);
        
      }*/
    });
  }

  increment(book : any) {
    var jsonArray = JSON.parse(JSON.stringify(book));
    this.service.increment(book).subscribe();
    this.ngOnInit();
  }

  decrement(book : any) {
    if (book.count > 0) {
      var jsonArray = JSON.parse(JSON.stringify(book));
      this.service.decrement(book).subscribe();
      this.ngOnInit();
    }
  }
}
