import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UploadbooksComponent } from './uploadbooks.component';

describe('UploadbooksComponent', () => {
  let component: UploadbooksComponent;
  let fixture: ComponentFixture<UploadbooksComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UploadbooksComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UploadbooksComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
