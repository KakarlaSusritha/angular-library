export class BookCSVRecord {
    bookId : any;
    bookTitle : any;
    bookAuthor : any;
    count: any;
}