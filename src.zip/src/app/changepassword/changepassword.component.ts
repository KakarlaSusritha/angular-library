import { Component, OnInit } from '@angular/core';
import { UserService } from '../user.service';

@Component({
  selector: 'app-changepassword',
  templateUrl: './changepassword.component.html',
  styleUrls: ['./changepassword.component.css']
})
export class ChangepasswordComponent implements OnInit {

  password1 : any;
  password2 : any;
  user : any;
  msg :  any;
  constructor(private service: UserService) { 
    this.password1 = ""; 
    this.password2 = "";
  }

  ngOnInit() {
  }

  changePassword() {
    if (this.password1 === this.password2) {
      this.user = this.service.getUser();
      this.user.userPassword = this.password1;
      var jsonArray = JSON.parse(JSON.stringify(this.user));
      this.service.changePassword(this.user).subscribe();
    } else {
      this.msg = "Passwords did'nt match..Please re-enter the password";
    }
    this.password1 = ""; 
    this.password2 = "";
}
}
