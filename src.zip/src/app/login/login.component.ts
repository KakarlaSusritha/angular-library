import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ValidateService } from '../validate.service';
import { UserService } from '../user.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  librarian : any;
  user : any;
  validateLib : any;
  validateStud : any;
  student : any;
  constructor(private router: Router, private validateService : ValidateService, private userService : UserService) { 
      this.user = {loginId: '', password: ''};
      this.librarian = {loginId: '', password: ''};
  }

  ngOnInit() {
  }

  async validateLibrarian() {
    if (this.librarian.loginId === 'librarian' && this.librarian.password === "lib") {
      this.validateService.setUserLoggedIn();
      this.router.navigate(['librarian']);
    } else {
      this.validateLib = 'Invalid User Credentials..'; 
    }
  }
 
  async validateUser() {
    if (this.user.loginId.substring(32,26) === 'edu.in') {
      console.log(this.user.loginId.substring(32,26));
      await this.validateService.getUserByLoginId(this.user.loginId).then((data: any) => {
        this.student= data; console.log('Inside subscribe');
       });
      this.validateService.setUserLoggedIn();
      this.userService.setUser(this.student);
      if (this.student.userPassword === this.user.password) {
        this.router.navigate(['user']);
      } else {
      this.validateStud = 'Invalid User Credentials..'; 
      }
    }
  }
}
