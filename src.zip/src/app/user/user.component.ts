import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UserService } from '../user.service';

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent implements OnInit {

  books : any;
  constructor(private router: Router, private service : UserService) {

  }
  ngOnInit() {
    //this.userId = this.service.getUserId();
    this.service.getAllBooks().subscribe(data => {console.log(data); this.books = data});
  
  }

}
