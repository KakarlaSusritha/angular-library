import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { UserComponent } from './user/user.component';
import { LibrarianComponent } from './librarian/librarian.component';
import { RouterModule, Routes } from '@angular/router';
import { LibheaderComponent } from './libheader/libheader.component';
import { UploadbooksComponent } from './uploadbooks/uploadbooks.component';
import { UploadusersComponent } from './uploadusers/uploadusers.component';
import { UserheaderComponent } from './userheader/userheader.component';
import { ChangepasswordComponent } from './changepassword/changepassword.component';
import { AuthguardGuard } from './authguard.guard';
import { HeaderComponent } from './header/header.component';
const appRoot: Routes = [
  {path: '', component: LoginComponent},
  {path: 'login', component: LoginComponent},
  {path: 'librarian',canActivate:[AuthguardGuard], component: LibrarianComponent},
  {path: 'user',canActivate:[AuthguardGuard], component: UserComponent},
  {path: 'uploadbooks',canActivate:[AuthguardGuard], component: UploadbooksComponent},
  {path: 'uploadusers',canActivate:[AuthguardGuard], component: UploadusersComponent},
  {path: 'password',canActivate:[AuthguardGuard], component: ChangepasswordComponent},
  {
    path: 'librarian',
    component: LibrarianComponent,
    children: [
      {path: 'uploadbooks', component: UploadbooksComponent},
      {path: 'uploadusers', component: UploadusersComponent},
    ]
  },
  {
    path: 'user',
    component: UserComponent,
    children: [
      {path: 'password', component: ChangepasswordComponent}
    ]
  }

]

  
@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    UserComponent,
    LibrarianComponent,
    LibheaderComponent,
    UploadbooksComponent,
    UploadusersComponent,
    UserheaderComponent,
    ChangepasswordComponent,
    HeaderComponent,

  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    RouterModule.forRoot(appRoot),
    RouterModule.forChild(appRoot)

  ],
  providers: [ ],
  bootstrap: [AppComponent]
})
export class AppModule { }
