import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Subject, Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class UserService {
  
  countToAdd: Subject<any>;
  count : any; 
  user : any;

  constructor(private httpClient : HttpClient) {
    this.countToAdd = new Subject();
   }

  registerBooks(books : any) : any {
    console.log(books);
    return this.httpClient.post("RestAPI/webapi/myresource/registerBooks/" , books);
  }

  registerUsers(users : any) : any {
      return this.httpClient.post("RestAPI/webapi/myresource/registerUsers/" , users);
  }

  getUserById(id : any) {
    return this.httpClient.get('RestAPI/webapi/myresource/getUserById/'+ id);
  }

  increment(book : any) : Observable<any> {
    console.log(book);
    return this.httpClient.post('RestAPI/webapi/myresource/increment/' , book);
  }

  decrement(book : any) : Observable<any> {
    console.log(book);
    return this.httpClient.post('RestAPI/webapi/myresource/decrement/' , book);
  }

  changePassword(user : any) : any {
    return this.httpClient.post('RestAPI/webapi/myresource/changePassword/' , user);
  }

  getAllBooks() : Observable<any> {
    return this.httpClient.get('RestAPI/webapi/myresource/getBooks');
  }

  getUser() {
    return this.user;  
  }

  setUser(student: any) {
    this.user = student;
  }

  getCount(): any {
    return this.count;
  }
  setCount(count : any){
    return this.count = count;
  }
  addToTable(count: any) {
    this.countToAdd.next(count);
  }
  getToTable(){
    return this.countToAdd.asObservable();
  }
  

}
