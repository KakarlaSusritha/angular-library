import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class ValidateService {
 
  flag: boolean;
  constructor(private httpClient: HttpClient) {}
  setUserLoggedIn() {
    this.flag = true;
  }
  getUserLogged(): boolean {
    return this.flag;
  }
  setUserLoggedOut() {
    this.flag = false;
  }
  getUserByLoginId(loginId: string): any {
    console.log(loginId);
    return this.httpClient.get('RestAPI/webapi/myresource/getUserByLoginId/' + loginId).toPromise();
  }
}
