import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ValidateService } from '../validate.service';
import { UserService } from '../user.service';

@Component({
  selector: 'app-libheader',
  templateUrl: './libheader.component.html',
  styleUrls: ['./libheader.component.css']
})
export class LibheaderComponent implements OnInit {

  count :any;

  constructor(private router: Router, private service: ValidateService, private userService : UserService) { 
    this.count =[];
  }

  ngOnInit() {
    this.userService.getToTable().subscribe(count => this.count.push(count));
    console.log(this.count);
    this.userService.setCount(this.count);
  }

  logOut() {
    this.service.setUserLoggedOut();
    this.router.navigate(['login']);
  }

}
