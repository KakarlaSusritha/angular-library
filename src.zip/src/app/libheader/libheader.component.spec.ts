import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LibheaderComponent } from './libheader.component';

describe('LibheaderComponent', () => {
  let component: LibheaderComponent;
  let fixture: ComponentFixture<LibheaderComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LibheaderComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LibheaderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
